const Contact = () => {
  return (
    <>
      <div className="text-center">
        <h2>Envie perguntas, ideias ou sugestões para</h2>
        <h4 className="mt-8">contato@statusimagens.com</h4>
      </div>
    </>
  );
};
export default Contact